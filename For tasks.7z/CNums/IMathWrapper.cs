﻿namespace C_Nums
{
    public interface IMathWrapper
    {
        double Pow(double x, double y);

        double Sqrt(double d);

        double Sin(double a);

        double Cos(double d);

        double Tan(double a);

        double Log(double d);

        double Log10(double d);

        double Exp(double d);

        double Abs(double value);

        double Round(double value);

        double Floor(double d);

        double Ceiling(double a);

        double Truncate(double d);

        double Max(double val1, double val2);

        double Min(double val1, double val2);

        double PI { get; }

        double Acos(double d);
    }
}