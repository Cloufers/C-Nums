﻿using C_Nums;

public class MathWrapper : IMathWrapper
{
    public double Pow(double x, double y) => Math.Pow(x, y);

    public double Sqrt(double d) => Math.Sqrt(d);

    public double Sin(double a) => Math.Sin(a);

    public double Cos(double d) => Math.Cos(d);

    public double Tan(double a) => Math.Tan(a);

    public double Log(double d) => Math.Log(d);

    public double Log10(double d) => Math.Log10(d);

    public double Exp(double d) => Math.Exp(d);

    public double Abs(double value) => Math.Abs(value);

    public double Round(double value) => Math.Round(value);

    public double Floor(double d) => Math.Floor(d);

    public double Ceiling(double a) => Math.Ceiling(a);

    public double Truncate(double d) => Math.Truncate(d);

    public double Max(double val1, double val2) => Math.Max(val1, val2);

    public double Min(double val1, double val2) => Math.Min(val1, val2);

    public double PI => Math.PI;

    public double Acos(double d) => Math.Acos(d);
}