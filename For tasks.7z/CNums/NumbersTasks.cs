﻿using C_Nums;

namespace Csharp_Nums
{
    public class NumbersTasks
    {
        private readonly IMathWrapper _mathWrapper;

        public NumbersTasks(IMathWrapper mathWrapper)
        {
            _mathWrapper = mathWrapper;
        }

        // Calculate the area of a rectangle given its width and height.
        public double GetRectangleArea(double width, double height)
        {
            throw new NotImplementedException();
        }

        // Calculate the circumference of a circle given its radius.
        public double GetCircleCircumference(double radius)
        {
            throw new NotImplementedException();
        }

        // Calculate the average of two given numbers.
        public double GetAverage(double value1, double value2)
        {
            throw new NotImplementedException();
        }

        // Calculate the distance between two points in a Cartesian plane.
        public double GetDistanceBetweenPoints(double x1, double y1, double x2, double y2)
        {
            throw new NotImplementedException();
        }

        // Calculate the root of a linear equation of the form a*x + b = 0.
        public double GetLinearEquationRoot(double a, double b)
        {
            throw new NotImplementedException();
        }

        // Calculate the angle (in radians) between two vectors in a Cartesian plane.
        public double GetAngleBetweenVectors(double x1, double y1, double x2, double y2)
        {
            throw new NotImplementedException();
        }

        // Return the last digit of a given integer.
        public int GetLastDigit(int value)
        {
            throw new NotImplementedException();
        }

        // Parse a number from a given string representation.
        public double ParseNumberFromString(string value)
        {
            throw new NotImplementedException();
        }

        // Calculate the diagonal length of a rectangular parallelepiped given its sides.
        public double GetParallelepipedDiagonal(double a, double b, double c)
        {
            throw new NotImplementedException();
        }

        // Round a number to the specified power of 10.
        public double RoundToPowerOfTen(double num, int pow)
        {
            throw new NotImplementedException();
        }

        // Check if a number is prime.
        public bool IsPrime(int n)
        {
            throw new NotImplementedException();
        }

        // Convert a value to a number, or return a default value if conversion fails.
        public double ToNumber(object value, double def)
        {
            throw new NotImplementedException();
        }

        // Calculate the cube of a given number.
        public double GetCube(double num)
        {
            throw new NotImplementedException();
        }

        // Calculate the Fibonacci number at the given index.
        public int GetFibonacciNumber(int index)
        {
            throw new NotImplementedException();
        }

        // Calculate the sum of all numbers from 1 to n.
        public int GetSumToN(int n)
        {
            throw new NotImplementedException();
        }

        // Calculate the sum of the digits of a given number.
        public int GetSumOfDigits(int num)
        {
            throw new NotImplementedException();
        }

        // Check if a number is a power of two.
        public bool IsPowerOfTwo(int num)
        {
            throw new NotImplementedException();
        }

        // Calculate the sine of a given number.
        public double GetSine(double num)
        {
            throw new NotImplementedException();
        }

        // Convert a number to a string representation in the specified base.
        public string NumberToStringInBase(int number, int baseValue)
        {
            throw new NotImplementedException();
        }

        // Convert a number to its exponential notation with the specified number of fraction digits.
        public string ToExponential(double number, int fractionDigits)
        {
            throw new NotImplementedException();
        }

        // Convert a number to its fixed-point notation with the specified number of fraction digits.
        public string ToFixed(double number, int fractionDigits)
        {
            throw new NotImplementedException();
        }

        // Convert a number to its normal (fixed-point or exponential) notation rounded to the specified precision.
        public string ToPrecision(double number, int precision)
        {
            throw new NotImplementedException();
        }

        // Get the primitive value of a Number object.
        public double GetNumberValue(object number)
        {
            throw new NotImplementedException();
        }

        // Check if a value is a number.
        public bool IsNumber(object number)
        {
            throw new NotImplementedException();
        }

        // Check if a value is an integer.
        public bool IsInteger(object number)
        {
            throw new NotImplementedException();
        }

        // Parse a floating-point number from a string, or return NaN if parsing fails.
        public double GetFloatOnString(string str)
        {
            throw new NotImplementedException();
        }

        // Parse an integer from a string in the specified base, or return NaN if parsing fails.
        public int GetIntegerOnString(string str, int baseValue)
        {
            throw new NotImplementedException();
        }

        // Check if a number is a safe integer.
        public bool IsSafeInteger(double number)
        {
            throw new NotImplementedException();
        }

        // Round a number to the smallest integer less than or equal to the number.
        public int RoundToSmallestInteger(double number)
        {
            throw new NotImplementedException();
        }

        // Round a number to the largest integer greater than or equal to the number.
        public int RoundToLargestInteger(double number)
        {
            throw new NotImplementedException();
        }

        // Round a number to the nearest integer.
        public int RoundToNearestInteger(double number)
        {
            throw new NotImplementedException();
        }

        // Get the integer part of a number by removing any fractional digits.
        public int GetIntegerPartNumber(double number)
        {
            throw new NotImplementedException();
        }

        // Calculate the sum of three numbers.
        public double GetSumOfNumbers(double x1, double x2, double x3)
        {
            throw new NotImplementedException();
        }

        // Return the largest of two numbers.
        public double GetMaxNumber(double firstNumber, double secondNumber)
        {
            throw new NotImplementedException();
        }

        // Return a random integer in the range from min to max.
        public int GetRandomInteger(int min, int max)
        {
            throw new NotImplementedException();
        }

        // Calculate the length of the hypotenuse of a right triangle.
        public double GetHypotenuse(double a, double b)
        {
            throw new NotImplementedException();
        }

        // Calculate the count of odd numbers from zero to the given number (inclusive).
        public int GetCountOfOddNumbers(int number)
        {
            throw new NotImplementedException();
        }
    }
}