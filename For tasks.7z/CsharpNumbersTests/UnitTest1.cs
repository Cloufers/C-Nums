using Moq;
using Csharp_Nums;
using C_Nums;

namespace C_nums
{
    public class TestCounter : IDisposable
    {
        public int CompletedTasks { get; private set; }

        public void Increment()
        {
            CompletedTasks++;
            Console.WriteLine($"Completed tasks: {CompletedTasks} of 37");
        }

        public void Dispose()
        {
            // Cleanup if needed
        }
    }

    public class NumbersTasksTests : IClassFixture<TestCounter>
    {
        private readonly Mock<IMathWrapper> _mockMath;
        private readonly NumbersTasks _numbersTasks;
        private readonly TestCounter _testCounter;

        public NumbersTasksTests(TestCounter testCounter)
        {
            _mockMath = new Mock<IMathWrapper>();
            _numbersTasks = new NumbersTasks(_mockMath.Object);
            _testCounter = testCounter;
        }

        [Fact]
        public void TestGetRectangleArea()
        {
            // Arrange
            double width = 5;
            double height = 10;

            // Act
            double result = _numbersTasks.GetRectangleArea(width, height);

            // Assert
            Assert.Equal(50, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetCircleCircumference()
        {
            // Arrange
            double radius = 5;
            _mockMath.Setup(m => m.PI).Returns(Math.PI);

            // Act
            double result = _numbersTasks.GetCircleCircumference(radius);

            // Assert
            Assert.Equal(2 * Math.PI * radius, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetAverage()
        {
            // Arrange
            double value1 = 10;
            double value2 = 20;

            // Act
            double result = _numbersTasks.GetAverage(value1, value2);

            // Assert
            Assert.Equal(15, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetDistanceBetweenPoints()
        {
            // Arrange
            double x1 = 0;
            double y1 = 0;
            double x2 = 3;
            double y2 = 4;
            _mockMath.Setup(m => m.Sqrt(It.IsAny<double>())).Returns(5);

            // Act
            double result = _numbersTasks.GetDistanceBetweenPoints(x1, y1, x2, y2);

            // Assert
            Assert.Equal(5, result);
            _mockMath.Verify(m => m.Sqrt(It.IsAny<double>()), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetLinearEquationRoot()
        {
            // Arrange
            double a = 2;
            double b = -4;

            // Act
            double result = _numbersTasks.GetLinearEquationRoot(a, b);

            // Assert
            Assert.Equal(2, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetAngleBetweenVectors()
        {
            // Arrange
            double x1 = 1;
            double y1 = 0;
            double x2 = 0;
            double y2 = 1;
            _mockMath.Setup(m => m.Acos(It.IsAny<double>())).Returns(Math.PI / 2);

            // Act
            double result = _numbersTasks.GetAngleBetweenVectors(x1, y1, x2, y2);

            // Assert
            Assert.Equal(Math.PI / 2, result);
            _mockMath.Verify(m => m.Acos(It.IsAny<double>()), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetLastDigit()
        {
            // Arrange
            int value = 123;

            // Act
            int result = _numbersTasks.GetLastDigit(value);

            // Assert
            Assert.Equal(3, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestParseNumberFromString()
        {
            // Arrange
            string value = "123.45";

            // Act
            double result = _numbersTasks.ParseNumberFromString(value);

            // Assert
            Assert.Equal(123.45, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetParallelepipedDiagonal()
        {
            // Arrange
            double a = 1;
            double b = 2;
            double c = 3;
            _mockMath.Setup(m => m.Sqrt(It.IsAny<double>())).Returns(Math.Sqrt(14));

            // Act
            double result = _numbersTasks.GetParallelepipedDiagonal(a, b, c);

            // Assert
            Assert.Equal(Math.Sqrt(14), result);
            _mockMath.Verify(m => m.Sqrt(It.IsAny<double>()), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestRoundToPowerOfTen()
        {
            // Arrange
            double num = 1234.56;
            int pow = 2;
            _mockMath.Setup(m => m.Pow(10, pow)).Returns(100);

            // Act
            double result = _numbersTasks.RoundToPowerOfTen(num, pow);

            // Assert
            Assert.Equal(1200, result);
            _mockMath.Verify(m => m.Pow(10, pow), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestIsPrime()
        {
            // Arrange
            int n = 7;

            // Act
            bool result = _numbersTasks.IsPrime(n);

            // Assert
            Assert.True(result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestToNumber()
        {
            // Arrange
            object value = "123.45";
            double def = 0;

            // Act
            double result = _numbersTasks.ToNumber(value, def);

            // Assert
            Assert.Equal(123.45, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetCube()
        {
            // Arrange
            double num = 3;
            _mockMath.Setup(m => m.Pow(num, 3)).Returns(27);

            // Act
            double result = _numbersTasks.GetCube(num);

            // Assert
            Assert.Equal(27, result);
            _mockMath.Verify(m => m.Pow(num, 3), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetFibonacciNumber()
        {
            // Arrange
            int index = 5;

            // Act
            int result = _numbersTasks.GetFibonacciNumber(index);

            // Assert
            Assert.Equal(5, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetSumToN()
        {
            // Arrange
            int n = 5;

            // Act
            int result = _numbersTasks.GetSumToN(n);

            // Assert
            Assert.Equal(15, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetSumOfDigits()
        {
            // Arrange
            int num = 123;

            // Act
            int result = _numbersTasks.GetSumOfDigits(num);

            // Assert
            Assert.Equal(6, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestIsPowerOfTwo()
        {
            // Arrange
            int num = 8;

            // Act
            bool result = _numbersTasks.IsPowerOfTwo(num);

            // Assert
            Assert.True(result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetSine()
        {
            // Arrange
            double num = Math.PI / 2;
            _mockMath.Setup(m => m.Sin(num)).Returns(1);

            // Act
            double result = _numbersTasks.GetSine(num);

            // Assert
            Assert.Equal(1, result);
            _mockMath.Verify(m => m.Sin(num), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestNumberToStringInBase()
        {
            // Arrange
            int number = 255;
            int baseValue = 16;

            // Act
            string result = _numbersTasks.NumberToStringInBase(number, baseValue);

            // Assert
            Assert.Equal("ff", result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestToExponential()
        {
            // Arrange
            double number = 1234.56;
            int fractionDigits = 2;

            // Act
            string result = _numbersTasks.ToExponential(number, fractionDigits);

            // Assert
            Assert.Equal("1.23E+003", result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestToFixed()
        {
            // Arrange
            double number = 1234.56;
            int fractionDigits = 2;

            // Act
            string result = _numbersTasks.ToFixed(number, fractionDigits);

            // Assert
            Assert.Equal("1234.56", result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestToPrecision()
        {
            // Arrange
            double number = 1234.56;
            int precision = 4;

            // Act
            string result = _numbersTasks.ToPrecision(number, precision);

            // Assert
            Assert.Equal("1235", result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetNumberValue()
        {
            // Arrange
            object number = 123.45;

            // Act
            double result = _numbersTasks.GetNumberValue(number);

            // Assert
            Assert.Equal(123.45, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestIsNumber()
        {
            // Arrange
            object number = 123.45;

            // Act
            bool result = _numbersTasks.IsNumber(number);

            // Assert
            Assert.True(result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestIsInteger()
        {
            // Arrange
            object number = 123;

            // Act
            bool result = _numbersTasks.IsInteger(number);

            // Assert
            Assert.True(result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetFloatOnString()
        {
            // Arrange
            string str = "123.45";

            // Act
            double result = _numbersTasks.GetFloatOnString(str);

            // Assert
            Assert.Equal(123.45, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetIntegerOnString()
        {
            // Arrange
            string str = "123";
            int baseValue = 10;

            // Act
            int result = _numbersTasks.GetIntegerOnString(str, baseValue);

            // Assert
            Assert.Equal(123, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestIsSafeInteger()
        {
            // Arrange
            double number = 123;

            // Act
            bool result = _numbersTasks.IsSafeInteger(number);

            // Assert
            Assert.True(result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestRoundToSmallestInteger()
        {
            // Arrange
            double number = 123.45;
            _mockMath.Setup(m => m.Floor(number)).Returns(123);

            // Act
            int result = _numbersTasks.RoundToSmallestInteger(number);

            // Assert
            Assert.Equal(123, result);
            _mockMath.Verify(m => m.Floor(number), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestRoundToLargestInteger()
        {
            // Arrange
            double number = 123.45;
            _mockMath.Setup(m => m.Ceiling(number)).Returns(124);

            // Act
            int result = _numbersTasks.RoundToLargestInteger(number);

            // Assert
            Assert.Equal(124, result);
            _mockMath.Verify(m => m.Ceiling(number), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestRoundToNearestInteger()
        {
            // Arrange
            double number = 123.45;
            _mockMath.Setup(m => m.Round(number)).Returns(123);

            // Act
            int result = _numbersTasks.RoundToNearestInteger(number);

            // Assert
            Assert.Equal(123, result);
            _mockMath.Verify(m => m.Round(number), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetIntegerPartNumber()
        {
            // Arrange
            double number = 123.45;

            // Act
            int result = _numbersTasks.GetIntegerPartNumber(number);

            // Assert
            Assert.Equal(123, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetSumOfNumbers()
        {
            // Arrange
            double x1 = 1;
            double x2 = 2;
            double x3 = 3;

            // Act
            double result = _numbersTasks.GetSumOfNumbers(x1, x2, x3);

            // Assert
            Assert.Equal(6, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetMaxNumber()
        {
            // Arrange
            double firstNumber = 1;
            double secondNumber = 2;
            _mockMath.Setup(m => m.Max(firstNumber, secondNumber)).Returns(2);

            // Act
            double result = _numbersTasks.GetMaxNumber(firstNumber, secondNumber);

            // Assert
            Assert.Equal(2, result);
            _mockMath.Verify(m => m.Max(firstNumber, secondNumber), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetRandomInteger()
        {
            // Arrange
            int min = 1;
            int max = 10;

            // Act
            int result = _numbersTasks.GetRandomInteger(min, max);

            // Assert
            Assert.InRange(result, min, max);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetHypotenuse()
        {
            // Arrange
            double a = 3;
            double b = 4;
            _mockMath.Setup(m => m.Sqrt(It.IsAny<double>())).Returns(5);

            // Act
            double result = _numbersTasks.GetHypotenuse(a, b);

            // Assert
            Assert.Equal(5, result);
            _mockMath.Verify(m => m.Sqrt(It.IsAny<double>()), Times.Once);

            // Increment the counter
            _testCounter.Increment();
        }

        [Fact]
        public void TestGetCountOfOddNumbers()
        {
            // Arrange
            int number = 5;

            // Act
            int result = _numbersTasks.GetCountOfOddNumbers(number);

            // Assert
            Assert.Equal(3, result);
            _mockMath.Verify(m => m.Pow(It.IsAny<double>(), It.IsAny<double>()), Times.Never);

            // Increment the counter
            _testCounter.Increment();
        }
    }
}